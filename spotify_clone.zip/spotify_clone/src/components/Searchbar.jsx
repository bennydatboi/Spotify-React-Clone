const Searchbar = () => (
  <div>Loader</div>
);

export default Searchbar;
